TQNL Faithful Vanilla Tweaks - Legacy 32x compilation
Minecraft 1.21 - 1.21.8

This is the original complete repository compilation from commit 8514066836949be584ddb1fa68e88fcb2db352e3.
It retains the original block, entity, item, utility, painting/bucket and visual indicator tweaks,
including VisualWaxedCopperItems. See report.txt for the original contents and contributors.
The repository remains a full compilation; newer copper-only V3 editions are separate downloads.

Use above the matching Faithful 32x base pack. Continuity is needed for included CTM effects;
CIT Resewn or a compatible CIT implementation is needed for included CIT effects.
Features apply only where the corresponding items/entities exist in that client.
Dormant files for later copper items are preserved from the historical repository.

The historical metadata began at resource format34 and used version overlays,
so it was intended for a combined interval. Its oversized7500 maximum is replaced
here by the pre-1.21.9 formats34-64. All original resource bytes are unchanged.
Metadata and resource selection were checked; no new all-feature in-game test was run.

Credits:
Vanilla Tweaks: https://vanillatweaks.net/
Faithful: https://faithfulpack.net/
Faithful License: https://faithfulpack.net/license/
