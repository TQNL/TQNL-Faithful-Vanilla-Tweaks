VisualWaxedCopperItems V3 - 16x Statue Patch
Minecraft 1.21.9 - 26.3

Place this ZIP in .minecraft/resourcepacks and enable it above other packs.
This contains the complete item-only tweak, including native pose-aware statue fixes.
Placed copper blocks and live golems are unchanged. No full Faithful pack is bundled.
16x rendering assets are identical to the previously accepted exact-release repair.

Sources: https://vanillatweaks.net/ and https://faithfulpack.net/
Faithful License: https://faithfulpack.net/license/
Overlays select exact-family textures and the 26.1+ statue transformation.
