VisualWaxedCopperItems V3 - Faithful 64x
Minecraft 26.1.1

Place this ZIP in .minecraft/resourcepacks and enable it above other packs.
This contains the complete item-only tweak, including native pose-aware statue fixes.
Placed copper blocks and live golems are unchanged. No full Faithful pack is bundled.
Use above the matching official Faithful 64x pack for a consistent world.
Wax bands: 2 pixels on ordinary faces, narrowed on tiny UV islands.
These new texture editions were checked offline; no Minecraft visual test was performed.

Sources: https://vanillatweaks.net/ and https://faithfulpack.net/
Faithful License: https://faithfulpack.net/license/
