VisualWaxedCopperItems V3 - Faithful 32x
Minecraft 1.21.9 - 26.3

Place this ZIP in .minecraft/resourcepacks and enable it above other packs.
This contains the complete item-only tweak, including native pose-aware statue fixes.
Placed copper blocks and live golems are unchanged. No full Faithful pack is bundled.
Use above the matching official Faithful 32x pack for a consistent world.
Wax bands: 1 pixels on ordinary faces, narrowed on tiny UV islands.
These new texture editions were checked offline; no Minecraft visual test was performed.

Sources: https://vanillatweaks.net/ and https://faithfulpack.net/
Faithful License: https://faithfulpack.net/license/
Overlays select exact-family textures and the 26.1+ statue transformation.
